/***************************************************************************
*                                 MICA  © 2018
*                           MIT BioInstrumentation Lab
*
* File: mockFunctions.c
* Workspace: micaComponents_testing
* Project: packetTesting_v1_4
* Version: 1.0.0
* Authors: Craig Cheney
* 
* PCB: SupportCube 2.1.1
* PSoC: CYBLE-214015-01
*
* Brief:
*   Functions for testing the receive functionality of the parser
*
* 2018.10.04  - Document Created
********************************************************************************/
#include "mockFunctions.h"

/*******************************************************************************
* Function Name: <functionName>()
****************************************************************************//**
* \brief
*  <function description>
*
* \param <paramName>
*  <param description>
*
* \return
*  <return description>
*******************************************************************************/


/* [] END OF FILE */
