/***************************************************************************
*                                 MICA  © 2018
*                           MIT BioInstrumentation Lab
*
* File: testFile.c
* Workspace: micaComponent_testing
* Project: fileGenerators_v1_0
* Version: 1.0.0
* Authors: Craig Cheney
* 
* PCB: Generic Generic
* PSoC: CYBLE-21405-01
*
* Brief:
*   
*
* 2018.10.01  - Document Created
********************************************************************************/
#include "testFile.h"

/*******************************************************************************
* Function Name: <fileName>()
****************************************************************************//**
* \brief
*  <function description>
*
* \param <paramName>
*  <param description>
*
* \return
*  <return description>
*******************************************************************************/


/* [] END OF FILE */
