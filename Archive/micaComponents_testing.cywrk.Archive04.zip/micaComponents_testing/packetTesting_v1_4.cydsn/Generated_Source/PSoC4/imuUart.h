/***************************************************************************//**
* \file imuUart.h
* \version 1.1
*
* \brief
*   Simple print functionality
*
* \date Date Created:  2017.12.19
* \date Last Modified: 2017.12.19
*
********************************************************************************
* \copyright
* Copyright 2017, MICA. All rights reserved.
*******************************************************************************/
/* Header Guard */
#ifndef imuUart_H
    #define imuUart_H
    /***************************************
    * Included files
    ***************************************/
    #include "cytypes.h"
    
    #define imuUart_SCB_STATUS     (1)
    
    #if (imuUart_SCB_STATUS)
        #include "UART_IMU_SPI_UART.h"
    #else
    
    #endif /* End `isScb` */ 
    /***************************************
    * Function declarations 
    ***************************************/
    void imuUart_print(char8 *pszFmt,...);
    void imuUart_txTest(uint8 runs);
    void imuUart_putString(char * str);
    void imuUart_putChar(uint8_t byte);
    void imuUart_putArray(uint8 * array, uint16 length);
    void imuUart_printHeader(char* time, char* date, char * name);
    void imuUart_dummyTxArray(uint8 * array, uint16 len);
    
    
    /* RX functions */
    #define imuUart_RX_EN  1        /**< Is receiving enabled? */
    #if imuUart_RX_EN
        uint32_t imuUart_getRxBufferSize(void);
        uint8_t imuUart_getChar(void);
    #endif /* imuUart_RX_EN */
   
    
    /***************************************
    * Macro Definitions
    ***************************************/
    #define imuUart_Start()    UART_IMU_Start()
    #define imuUart_clearScreen()  imuUart_print("\033[2J\033[1;1H")    /**< Clear the terminal screen */

    
    /* Logging */ 
    #define imuUart_DEBUG_EN 1   /**< Is log printing enabled? */
    #if imuUart_DEBUG_EN
        #define imuUart_log(...) imuUart_print(__VA_ARGS__)  /**< Log Function */
    #else
        #define imuUart_log(...) do { (void)0; } while(0) /**< Without logging */
    #endif /*  */

    
#endif /* (imuUart_H) */
/* [] END OF FILE */
